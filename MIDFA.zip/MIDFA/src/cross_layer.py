import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange, repeat


# class DSW_embedding(nn.Module):
#     def __init__(self, seg_len, dim, dropout_rate=0.3, seg_dim=10):
#         super(DSW_embedding, self).__init__()
#         self.seg_len = seg_len
#
#         self.dim_linear = nn.Linear(1, seg_dim)
#         self.linear = nn.Linear(seg_len, dim)
#         self.res_linear = nn.Linear(dim * seg_dim * seg_dim, dim)
#
#         self.dropout = torch.nn.Dropout(dropout_rate)
#         self.norm_layer = torch.nn.LayerNorm(dim)
#
#     def forward(self, x):
#         batch_size = x.size(0)  # 计算当前批量大小
#         max_batch_size = 256  # 设置合适的小批量大小（根据显存调整）
#
#         # 如果当前批量大小大于最大批量大小，就进行分批处理
#         if batch_size > max_batch_size:
#             # 将批次分成多个小批次
#             num_batches = (batch_size + max_batch_size - 1) // max_batch_size
#             outputs = []
#
#             # 按小批次逐个处理
#             for i in range(num_batches):
#                 start_idx = i * max_batch_size
#                 end_idx = min((i + 1) * max_batch_size, batch_size)
#                 batch_x = x[start_idx:end_idx]
#
#                 # 处理该批次
#                 outputs.append(self._process_batch(batch_x))
#
#             # 合并所有小批次的结果
#             return torch.cat(outputs, dim=0)
#         else:
#             # 如果批量大小不大于最大批量大小，正常处理
#             return self._process_batch(x)
#
#     def _process_batch(self, x):
#         # 在这里写处理每个小批次的具体代码
#         x = x.unsqueeze(-1)
#         x = self.dim_linear(x)
#         batch, ts_len, ts_dim = x.shape
#         print(f"x.shape after dim_linear: {x.shape}")
#
#         # 修改这里，减少过大的维度
#         x_segment = rearrange(x, 'b (seg_num seg_len) d -> b d seg_num seg_len', seg_len=self.seg_len)
#         print(f"x_segment.shape: {x_segment.shape}")
#
#         x_embed = self.linear(x_segment)
#         print(f"x_embed.shape after linear: {x_embed.shape}")
#
#         # 重新考虑如何调整维度以匹配
#         x_embed = rearrange(x_embed, 'b (d seg_num seg_dim) -> b d seg_num seg_dim', b=batch, d=ts_dim)
#         print(f"x_embed.shape after rearrange: {x_embed.shape}")
#
#         # 适当调整维度后进行操作
#         x_embed = rearrange(x_embed, 'b d seg_num seg_dim -> b (d seg_num seg_dim)')
#         print(f"x_embed.shape after second rearrange: {x_embed.shape}")
#
#         x_embed = self.dropout(x_embed)
#         x_embed = self.res_linear(x_embed)
#         print(f"x_embed.shape after res_linear: {x_embed.shape}")
#
#         x_embed = self.norm_layer(x_embed)
#
#         return x_embed

class DSW_embedding(nn.Module):
    def __init__(self, input_dim, segment_size):
        super(DSW_embedding, self).__init__()
        # 线性层，输入和输出的维度都是segment_size
        self.linear = nn.Linear(segment_size, segment_size)
        self.input_dim = input_dim
        self.segment_size = segment_size

    def forward(self, dynamic_emb):
        # 1. 将每个特征向量分割为10个块（每块20维）
        chunks = dynamic_emb.view(dynamic_emb.size(0), 20, self.segment_size)

        # 2. 对每个块应用线性变换
        processed_chunks = self.linear(chunks)

        # 3. 将处理后的块重新拼接回200维
        processed_dynamic_emb = processed_chunks.view(dynamic_emb.size(0), -1)

        return processed_dynamic_emb